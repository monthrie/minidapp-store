/**
 * Schema Converter for MINIVOX
 * Converts between new unified schema and legacy API format
 * 
 * Payment Handling:
 * - convertPaymentToLegacy: Converts direct payments to format for sendPaymentTxn
 * - convertTipToLegacy: Converts vote entries to format for sendTxnTip (for post votes)
 */
const SchemaConverter = {
    // Helper function to ensure IDs are uppercase after 0x prefix
    ensureUppercaseId: function(id) {
        if (!id) return id;
        if (typeof id !== 'string') return id;
        
        // If starts with 0x, keep prefix lowercase and make rest uppercase
        if (id.toLowerCase().startsWith('0x')) {
            return '0x' + id.slice(2).toUpperCase();
        }
        // Otherwise just uppercase the whole thing
        return id.toUpperCase();
    },

    // Convert new schema message to legacy format for API handler
    convertMessageToLegacy: function(entry) {
        if (!entry || !entry.entryType) {
            return null;
        }
        
        if (entry.entryType === 'post' || entry.entryType === 'article') {
            return {
                category: entry.entryType.toUpperCase(), // 'post' or 'article'
                title: entry.title || "Minivox", // Default title if not provided
                message: entry.message,
                user: entry.author.userName,
                pubkey: entry.author.userPubkey,
                address: entry.author.address,
                randId: this.ensureUppercaseId(entry.id),
                created: entry.created,
                description: entry.description || "No description available."
            };
        }
        
        if (entry.entryType === 'reply') {
            return {
                category: entry.entryType.toUpperCase(),
                title: this.ensureUppercaseId(entry.targetId),
                message: entry.message,
                user: entry.author.userName,
                pubkey: entry.author.userPubkey,
                address: entry.author.address,
                randId: this.ensureUppercaseId(entry.id),
                created: entry.created,
                description: "No description available."
            };
        }
        
        return null; // For unhandled entry types
    },

    // Convert new schema payment to legacy format for direct payments (sendPaymentTxn)
    convertPaymentToLegacy: function(payment) {
        if (!payment || payment.entryType !== 'payment') {
            return null;
        }
        
        return {
            recipientAddr: payment.recipient && payment.recipient.address ? payment.recipient.address : null,
            amount: payment.amount,
            description: payment.description || '',
            isAnonymous: payment.isAnonymous || false
        };
    },

    // Convert new schema vote to legacy format for sendTxnTip
    convertTipToLegacy: function(entry) {
        if (!entry || entry.entryType !== 'vote') {
            return null;
        }
        
        // Handle vote type (content-related tip)
        return {
            userPubkey: entry.voter.userPubkey,
            recipientAddr: null, // Will be determined by targetId
            recipientPubkey: null, // Will be determined by targetId
            randId: this.ensureUppercaseId(entry.id),
            postId: this.ensureUppercaseId(entry.targetId),
            amount: entry.amount,
            isAmp: entry.isPositive,
            isReply: entry.isReply || false
        };
    },

    // Convert new schema poll to legacy format
    convertPollToLegacy: function(poll) {
        return {
            question: poll.question,
            options: poll.options.map(opt => opt.text),
            user: poll.author.userName,
            pubkey: poll.author.userPubkey,
            address: poll.author.address,
            randId: this.ensureUppercaseId(poll.id),
            created: poll.created
        };
    },

    // Convert new schema poll vote to legacy format
    convertPollVoteToLegacy: function(vote) {
        // Extract pollId and optionId without the 0x prefix
        // The new pattern for optionId is [pollId]_[index] without 0x prefix
        let pollId = this.ensureUppercaseId(vote.pollId);
        let optionId = vote.optionId; // Already in proper format (e.g., "12345_2")
        
        // If optionId still has the format 0x[pollId]_[index], extract just the [index]
        if (optionId.includes('0x')) {
            const parts = optionId.split('_');
            if (parts.length > 1) {
                optionId = `${pollId}_${parts[1]}`;
            }
        }
        
        return {
            pollId: pollId,
            optionId: optionId,
            pubkey: vote.voter.userPubkey
        };
    },

    // Helper function to determine if a targetId belongs to a reply
    isReplyTarget: function(targetId) {
        // Check if the entry with this targetId is a reply
        // This could be based on the entryType of the target
        return targetId && targetId.startsWith('0x') && this.getEntryType(targetId) === 'reply';
    },

    // Helper to get entry type (you'll need to implement this based on your data storage)
    getEntryType: function(id) {
        // Implementation to get entry type from your data store
        return 'post'; // Default implementation
    },

    // Helper to sanitize userName from possible extra quotes
    sanitizeUserName: function(userName) {
        if (!userName) return "";
        
        // Remove any extra quotes from userName, including escaped quotes
        return userName.replace(/^["']?(.*?)["']?$/, "$1").replace(/\\"/g, "");
    },

    // Convert legacy format to new schema (for responses)
    convertLegacyToNewSchema: function(legacyData, type) {
        if (!legacyData) return null;

        // Handle potential string response
        if (typeof legacyData === 'string') {
            try {
                legacyData = JSON.parse(legacyData);
            } catch (e) {
                // If parsing fails, return null
                return null;
            }
        }

        // Sanitize userName if present (do this before any other processing)
        if (legacyData.userName || legacyData.user) {
            const cleanName = this.sanitizeUserName(legacyData.userName || legacyData.user);
            legacyData.userName = cleanName;
            legacyData.user = cleanName;
        }
        if (legacyData.senderName) {
            legacyData.senderName = this.sanitizeUserName(legacyData.senderName);
        }

        switch(type) {
            case 'post':
                return {
                    id: this.ensureUppercaseId(legacyData.id),
                    created: Number(legacyData.created) || Date.now(),
                    entryType: 'post',
                    message: legacyData.message,
                    author: {
                        userName: this.sanitizeUserName(legacyData.user || legacyData.userName),
                        userPubkey: legacyData.pubkey || legacyData.userPubkey,
                        address: legacyData.address
                    }
                };
            
            case 'article':
                return {
                    id: this.ensureUppercaseId(legacyData.id),
                    created: Number(legacyData.created) || Date.now(),
                    entryType: 'article',
                    message: legacyData.message,
                    title: legacyData.title,
                    author: {
                        userName: this.sanitizeUserName(legacyData.user || legacyData.userName),
                        userPubkey: legacyData.pubkey || legacyData.userPubkey,
                        address: legacyData.address
                    }
                };
            
            case 'reply':
                return {
                    id: this.ensureUppercaseId(legacyData.id),
                    created: Number(legacyData.created) || Date.now(),
                    entryType: 'reply',
                    message: legacyData.message,
                    targetId: legacyData.targetId ? this.ensureUppercaseId(legacyData.title) : null,
                    author: {
                        userName: this.sanitizeUserName(legacyData.user || legacyData.userName),
                        userPubkey: legacyData.pubkey || legacyData.userPubkey,
                        address: legacyData.address
                    }
                };
            
            case 'payment':
                return {
                    id: this.ensureUppercaseId(legacyData.id),
                    created: Number(legacyData.created) || Date.now(),
                    entryType: 'payment',
                    sender: {
                        userName: this.sanitizeUserName(legacyData.senderName || legacyData.userName || legacyData.user),
                        userPubkey: legacyData.userPubkey,
                        address: legacyData.address
                    },
                    recipient: legacyData.recipientPubkey ? {
                        userPubkey: legacyData.recipientPubkey,
                        address: legacyData.recipientAddr
                    } : null,
                    amount: legacyData.amount,
                    coinId: this.ensureUppercaseId(legacyData.coinId),
                    targetId: this.ensureUppercaseId(legacyData.postId),
                    description: legacyData.description || '',
                    isAnonymous: legacyData.isAnonymous || false,
                    transactionId: this.ensureUppercaseId(legacyData.transactionId)
                };
            
            case 'poll':
                return {
                    id: this.ensureUppercaseId(legacyData.id),
                    created: Number(legacyData.created) || Date.now(),
                    entryType: 'poll',
                    question: legacyData.question,
                    options: legacyData.options.map((text, index) => ({
                        optionId: `${this.ensureUppercaseId(legacyData.randId)}_${index}`, // Format without 0x prefix
                        text,
                        voteCount: legacyData.voteCounts && legacyData.voteCounts[index] ? legacyData.voteCounts[index] : 0
                    })),
                    author: {
                        userName: this.sanitizeUserName(legacyData.user || legacyData.userName),
                        userPubkey: legacyData.pubkey || legacyData.userPubkey,
                        address: legacyData.address
                    }
                };

            case 'vote':
                return {
                    id: this.ensureUppercaseId(legacyData.id),
                    created: Number(legacyData.created) || Date.now(),
                    entryType: 'vote',
                    voter: {
                        userName: this.sanitizeUserName(legacyData.userName || legacyData.user),
                        userPubkey: legacyData.userPubkey || legacyData.pubkey,
                        address: legacyData.address
                    },
                    targetId: this.ensureUppercaseId(legacyData.postId),
                    isPositive: typeof legacyData.isAmp !== 'undefined' ? legacyData.isAmp : true,
                    isReply: !!legacyData.isReply,
                    amount: legacyData.amount || 0.1
                };

            case 'poll_vote':
                return {
                    id: this.ensureUppercaseId(legacyData.id),
                    created: Number(legacyData.created) || Date.now(),
                    entryType: 'poll_vote',
                    voter: {
                        userPubkey: legacyData.pubkey || legacyData.userPubkey,
                        userName: this.sanitizeUserName(legacyData.userName || legacyData.user),
                        address: legacyData.address
                    },
                    pollId: this.ensureUppercaseId(legacyData.pollId),
                    optionId: legacyData.optionId // Already in correct format (pollId_index)
                };

            case 'balance':
                return {
                    id: this.ensureUppercaseId(legacyData.id),
                    created: legacyData.created || Date.now(),
                    entryType: 'balance',
                    user: {
                        userName: this.sanitizeUserName(legacyData.userName || legacyData.user),
                        userPubkey: legacyData.userPubkey || legacyData.pubkey,
                        address: legacyData.address
                    },
                    token: legacyData.token,
                    tokenId: this.ensureUppercaseId(legacyData.tokenId),
                    confirmed: legacyData.confirmed || 0,
                    unconfirmed: legacyData.unconfirmed || 0,
                    sendable: legacyData.sendable || 0,
                    coins: legacyData.coins || 0,
                    total: legacyData.total || 0
                };
            
            case 'message':
                // Determine if it's a post, article, or reply
                const messageType = (legacyData.category || 'post').toLowerCase();
                return this.convertLegacyToNewSchema(legacyData, messageType);
                
            default:
                // If type is unknown, try to determine from the data
                if (legacyData.category) {
                    return this.convertLegacyToNewSchema(legacyData, legacyData.category.toLowerCase());
                }
                return null;
        }
    },

    // Convert read operation responses
    convertReadResponse: function(response, type) {
        if (!response || !response.status) return null;

        const data = response.response || response;
        if (!data) return null;

        return this.convertLegacyToNewSchema(data, type);
    }
};
