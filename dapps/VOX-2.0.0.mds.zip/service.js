/**
 * MINIVOX backend service
 *
 * @vdevs
 */

//Load js libs in dependency order
MDS.load("puresha1.js"); // Independent utility
MDS.load("jslib.js"); // Base utilities
MDS.load("utils.js"); // Uses MDS
MDS.load("sql.js"); // Database utilities
MDS.load("txn.js"); // Transaction utilities
MDS.load("coinReader.js"); // Uses jslib.js and utils.js
MDS.load("notifications.js"); // Uses MDS and service.js globals
MDS.load("transactionProcessors.js"); // Uses all above
MDS.load("schemaConverter.js"); // Uses all above
MDS.load("apihandler.js"); // API handling, loaded last

//Global state
var USER_NAME = "";
var USER_PUBKEY = "";
var USER_ADDRESS = "Mx999";

//Constants
const TEST_MODE = false;
const TEST_ADDRESS = "0x9998969234856793";
const TEST_TIP_ADDRESS = "0x99989692348567932359237958";
const MINIVOX_ADDRESS = TEST_MODE
  ? TEST_ADDRESS
  : "0x6D696E69766F782061646472657373";
const MINIVOX_TIP_ADDRESS = TEST_MODE
  ? TEST_TIP_ADDRESS
  : "0x4D494E49564F585F414444524553";
const currentDBVersion = "0.1.6";
let hourCount = 0;

/**
 * Main Initialization
 */

//Main message handler
MDS.init(function (msg) {
  if (msg.event === "inited") {
    MDS.log("MDS initialized");
    initializeDatabase();
  } else if (msg.event == "NOTIFYCOIN") {
    handleCoinNotification(msg);
  } else if (msg.event === "MDSAPI") {
    ApiHandler.handleRequest(msg);
  }
});

function initializeSystem() {
  setupCoinNotifications(() => {
    initializeUser();
  });
}

/**
 * Database Management
 */

function initializeDatabase() {
  MDS.keypair.get("vox_db_version", function (resp) {
    const version = resp.value;

    if (!resp.status || !version || version !== currentDBVersion) {
      MDS.log("DB version mismatch or not found, resetting DB");
      wipeDB(() => {
        createDB(() => {
          updateDBVersion(() => {
            MDS.keypair.set("vox_initial_import_done", "false", () => {
              initializeSystem();
            });
          });
        });
      });
    } else {
      MDS.log("DB version matches, verifying structure");
      createDB(() => {
        MDS.log("Database structure verified");
        initializeSystem();
      });
    }
  });
}

function updateDBVersion(callback) {
  MDS.keypair.set("vox_db_version", currentDBVersion, function (resp) {
    MDS.log("Database recreated and version updated to: " + currentDBVersion);
    callback();
  });
}

/**
 * User Management
 */

function initializeUser() {
  MDS.cmd("maxima;getaddress", function (startup) {
    USER_PUBKEY = startup[0].response.publickey;

    getUser(USER_PUBKEY, function (userResp) {
      if (userResp.count > 0) {
        USER_NAME = decodeStringFromDB(userResp.rows[0].USER_NAME);
        USER_ADDRESS = userResp.rows[0].USER_ADDRESS;
      } else {
        createNewUser(startup);
      }

      setupUserPreferences();
    });
  });
}

function createNewUser(startup) {
  USER_NAME = startup[0].response.name;
  USER_ADDRESS = startup[1].response.address;
  addNewUser(
    USER_PUBKEY,
    USER_NAME,
    USER_ADDRESS,
    Date.now(),
    0,
    0,
    null,
    function (sqlRes) {
      if (!sqlRes.status) {
        MDS.log("Error adding new user: " + sqlRes.error);
      }
    }
  );
}

function setupUserPreferences() {
  addUserPreferences(USER_PUBKEY, function (inserted) {
    if (inserted) {
      MDS.log("User Preferences added to table.");
    }

    checkUserExists(USER_PUBKEY, function (exists) {
      if (!exists) {
        createNewUser({
          0: { response: { name: USER_NAME } },
          1: { response: { address: USER_ADDRESS } },
        });
      } else {
        MDS.log("User already exists: " + USER_NAME);
      }
    });
  });
}

/**
 * Notification Management
 */

function setupCoinNotifications(callback) {
  MDS.cmd("coinnotify action:add address:" + MINIVOX_ADDRESS, function (resp) {
    MDS.cmd(
      "coinnotify action:add address:" + MINIVOX_TIP_ADDRESS,
      function (resp) {
        MDS.cmd(
          "coinnotify action:add address:" + USER_ADDRESS,
          function (resp) {
            MDS.log("Coin notifications set up");
            callback();
          }
        );
      }
    );
  });
}

function handleCoinNotification(msg) {
  const { address, coin } = msg.data;

  if (address === MINIVOX_ADDRESS || address === MINIVOX_TIP_ADDRESS) {
    if (stripBrackets(coin.state[0]) !== "PAYMENT") {
      if (!checkTxn(msg)) {
        MDS.log("ERROR: Invalid Message - Failed transaction check");
        return;
      }
    }

    // Handle different transaction types
    try {
      switch (address) {
        case MINIVOX_ADDRESS:
          processPostTransaction(coin, () => {});
          break;

        case MINIVOX_TIP_ADDRESS:
          const recipientAddr = stripBrackets(coin.state[3]);
          if (stripBrackets(coin.state[0]) === "PAYMENT") {
            MDS.cmd("checkaddress address:" + recipientAddr, function (resp) {
              if (resp.response.relevant) {
                processPaymentTransaction(coin, () => {});
              }
            });
          } else {
            handleTipAddress(coin);
          }
          break;

        default:
          MDS.log("Message received for unknown address: " + address);
      }
    } catch (error) {
      MDS.log("Error processing transaction: " + error);
    }
  }
}

// Separate tip address handling logic
function handleTipAddress(coin) {
  MDS.cmd("checkmode", function (resp) {
    const userPubkey = stripBrackets(coin.state[0]);

    // Skip processing if in write mode and transaction is from current user
    if (resp.response.writemode && userPubkey === USER_PUBKEY) {
      return;
    }

    const transactionType = stripBrackets(coin.state[8]).toUpperCase();
    const processor =
      transactionType === "POLL"
        ? processPollVoteTransaction
        : processTipTransaction;

    processor(coin, () => {});
  });
}
