/**
 * Transaction Processors
 *
 * All functions related to processing different types of transactions.
 * Dependencies:
 * - MDS from Minima
 * - USER_PUBKEY from service.js
 * From jslib.js:
 * - stripBrackets
 * - isChainMessageValid
 * - isChainTipValid
 * - isChainPollVoteValid
 * From utils.js:
 * - checkTxn
 * - decodeHexString
 * From coinReader.js:
 * - readMessageCoin
 * - readTipCoin
 * - readPollVoteCoin
 * - readPollCoin
 * - readReactionCoin
 * - readPaymentCoin
 * From notifications.js:
 * - notifyPost
 * - notifyReply
 * - notifyUpvote
 * - notifyPoll
 * - notifyPollVote
 * - notifyReaction
 * - notifyPayment
 * From sql.js:
 * - checkUserBlocked
 * - checkPollMessageSig
 * - checkMessageSig
 * - insertPollUpdateUser
 * - insertArticleUpdateUser
 * - insertReplyUpdateUser
 * - insertPostUpdateUser
 * - insertRepostUpdateUser
 * - updateReplyScore
 * - updatePostScore
 * - votePoll
 * - getPollWithOptions
 * - updateReactions
 */

function processPostTransaction(coin, /* isHistorical, */ callback) {
  const category = stripBrackets(coin.state[0]);

  if (category.toUpperCase() === "POLL") {
    readPollCoin(
      Object.assign({}, coin),
      /* isHistorical, */ (pollState) => {
        if (!pollState) {
          MDS.log("ERROR: Invalid poll state");
          callback(); // Continue with next transaction
          return;
        }

        const {
          id,
          userPubkey,
          question,
          options,
          randId,
          userName,
          address,
          created,
          description,
          signature,
        } = pollState;

        if (
          !isChainMessageValid(
            id,
            category,
            question,
            JSON.stringify({ question, options }),
            userName,
            randId,
            userPubkey,
            signature
          )
        ) {
          MDS.log("ERROR: Chain message validation failed - Details:");
          MDS.log(`ID: ${id}, Category: ${category}, Question: ${question}`);
          MDS.log(
            `Message: ${JSON.stringify({
              question,
              options,
            })}, User: ${userName}`
          );
          callback(); // Continue with next transaction
          return;
        }

        checkUserBlocked(userPubkey, function (isBlocked) {
          if (!isBlocked) {
            checkPollMessageSig(
              userPubkey,
              question,
              options,
              randId,
              created,
              signature,
              function (valid) {
                if (!valid) {
                  MDS.log("ERROR: Invalid Poll Signature");
                  callback(); // Continue with next transaction
                  return;
                }
                insertPollAndNotify();
              }
            );
          } else {
            MDS.log("ERROR: User is blocked");
            callback(); // Continue with next transaction
          }
        });

        function insertPollAndNotify() {
          insertPollUpdateUser(
            randId,
            userName,
            userPubkey,
            address,
            question,
            options,
            created,
            description,
            function (inserted) {
              if (inserted /* && !isHistorical */) {
                notifyPoll(userName, userPubkey, question, randId);
              }
              callback(); // Continue regardless of insert success
            }
          );
        }
      }
    );
    return;
  }

  if (category.toUpperCase() === "REACTION" || category.toUpperCase() === "REPLY_REACTION") {
    readReactionCoin(Object.assign({}, coin), (reactionState) => {
      if (!reactionState) {
        MDS.log("ERROR: Invalid reaction state");
        callback(); // Continue with next transaction
        return;
      }

      const {
        id,
        userPubkey,
        emoji,
        randId,
        postId,
        signature,
        created
      } = reactionState;

      checkUserBlocked(userPubkey, function (isBlocked) {
        if (!isBlocked) {
          checkReactionSig(userPubkey, postId, emoji, randId, signature, function(valid) {
            if (!valid) {
              MDS.log("ERROR: Invalid Reaction Signature");
              callback(); // Continue with next transaction
              return;
            }

            const updateReactionFunc = category.toUpperCase() === "REPLY_REACTION" ? updateReplyReactions : updateReactions;
            updateReactionFunc(postId, userPubkey, emoji, function (success) {
              if (success) {
                // Get user name for notification
                getUser(userPubkey, function(profile) {
                  if (profile && profile.status && profile.rows && profile.rows.length > 0 && profile.rows[0].USER_NAME) {
                    const userName = profile.rows[0].USER_NAME;
                    notifyReaction(postId, userName, emoji);
                  } else {
                    MDS.log("ERROR: Invalid profile data structure");
                  }
                });
              } else {
                MDS.log("ERROR: Failed to record reaction");
              }
              callback();
            });
          });
        } else {
          MDS.log("ERROR: User is blocked");
          callback(); // Continue with next transaction
        }
      });
    });
    return;
  }

  readMessageCoin(
    Object.assign({}, coin),
    /* isHistorical, */ (messageState) => {
      const {
        id,
        category,
        title,
        message,
        userName,
        userPubkey,
        address,
        randId,
        created,
        description,
        signature,
      } = messageState;

      if (
        !isChainMessageValid(
          id,
          category,
          title,
          message,
          userName,
          randId,
          userPubkey,
          signature
        )
      ) {
        MDS.log("ERROR: Chain message validation failed.");
        callback(); // Continue with next transaction
        return;
      }

      checkUserBlocked(userPubkey, function (isBlocked) {
        if (!isBlocked) {
          checkMessageSig(
            category,
            title,
            message,
            userName,
            userPubkey,
            address,
            randId,
            created,
            description,
            signature,
            function (valid) {
              if (!valid) {
                MDS.log("ERROR: Invalid Message Signature.");
                callback(); // Continue with next transaction
                return;
              }
              processMessageByCategory();
            }
          );
        } else {
          MDS.log("ERROR: User is blocked");
          callback(); // Continue with next transaction
        }
      });

    function processMessageByCategory() {
      const isRead = userPubkey === USER_PUBKEY ? 1 : 0;
      
      // Extract subv tag if present
      let subv = null;
      const subvMatch = message.match(/v\/(\w+)/);
      if (subvMatch) {
        subv = subvMatch[1];
      }

      switch (category) {
        case "ARTICLE":
          insertArticleUpdateUser(
            id,
            userName,
            userPubkey,
            address,
            title,
            message,
            isRead,
            created,
            description,
            subv,
            function (inserted) {
              if (inserted /* && !isHistorical */) {
                notifyPost(userName, userPubkey, message, id);
              }
              callback();
            }
          );
          break;
        case "REPLY":
          insertReplyUpdateUser(
            id,
            title,
            userPubkey,
            userName,
            address,
            message,
            created,
            description,
            function (inserted) {
              if (inserted /* && !isHistorical */) {
                notifyReply(title, userName, message);
              }
              callback(); // Continue regardless of insert success
            }
          );
          break;
        case "REPOST":
          insertRepostUpdateUser(
            id,
            userName,
            userPubkey,
            address,
            message,
            created,
            description,
            subv,
            function (inserted) {
              if (inserted /* && !isHistorical */) {
                const parsedMessage = JSON.parse(message);
                notifyRepost(userName, parsedMessage.repost.originalAuthorPubkey, id);
              }
              callback(); // Continue regardless of insert success
            }
          );
          break;
        case "POST":
        default:
          insertPostUpdateUser(
            id,
            userName,
            userPubkey,
            address,
            message,
            isRead,
            created,
            description,
            subv,
            function (inserted) {
              if (inserted /* && !isHistorical */) {
                notifyPost(userName, userPubkey, message, id);
              }
              callback(); // Continue regardless of insert success
            }
          );
          break;
      }
    }
  });
}

function processTipTransaction(coin, /* isHistorical, */ callback) {
  readTipCoin(coin, (tipState) => {
    const {
      userPubkey,
      recipientAddr,
      recipientPubkey,
      randId,
      postId,
      amount,
      signature,
      isAmp,
      isReply,
      isOldVersion,
      rawIsAmp,
    } = tipState;

    if (
      !isChainTipValid(
        userPubkey,
        recipientAddr,
        randId,
        postId,
        amount,
        isAmp,
        signature
      )
    ) {
      MDS.log(
        "ERROR: Cannot have blank details in tip." + JSON.stringify(tipState)
      );
      callback(); // Continue with next transaction
      return;
    }

    checkTipSig(
      userPubkey,
      recipientAddr,
      recipientPubkey,
      randId,
      postId,
      amount,
      isOldVersion ? rawIsAmp : isAmp,
      isReply,
      signature,
      function (valid) {
        if (!valid) {
          MDS.log("ERROR: Invalid Tip Signature");
          callback(); // Continue with next transaction
          return;
        }

        const voteScore = amount * 10;
        const updateScoreFunction = isReply
          ? updateReplyScore
          : updatePostScore;

        updateScoreFunction(postId, voteScore, isAmp, function (sqlResp) {
          if (sqlResp.status) {
            // if (!isHistorical) {
            MDS.log("Post score updated: " + postId);
            if (isAmp) {
            notifyUpvote(recipientPubkey, voteScore, postId);
            }
            // }
          } else {
            MDS.log("ERROR: Score update failed. " + sqlResp);
          }
          callback(); // Continue regardless of update success
        });
      }
    );
  });
}

function processPollVoteTransaction(coin, /* isHistorical, */ callback) {
  readPollVoteCoin(coin, (voteState) => {
    const { userPubkey, pollId, optionId, randId, signature } = voteState;

    if (userPubkey === USER_PUBKEY) {
      getPollWithOptions(pollId, function (pollData) {
        if (pollData.status && pollData.poll && pollData.poll.IS_VOTED) {
          MDS.log("ERROR: User has already voted on this poll");
          callback(); // Continue with next transaction
          return;
        }
      });
    }

    if (
      !isChainPollVoteValid(userPubkey, pollId, optionId, randId, signature)
    ) {
      MDS.log("ERROR: Cannot have blank details in poll vote.");
      callback(); // Continue with next transaction
      return;
    }

    checkPollVoteSig(
      userPubkey,
      pollId,
      optionId,
      randId,
      signature,
      function (valid) {
        if (!valid) {
          MDS.log("ERROR: Invalid Poll Vote Signature for: " + userPubkey);
          callback(); // Continue with next transaction
          return;
        }

        const isCurrentUser = userPubkey === USER_PUBKEY;

        votePoll(pollId, optionId, isCurrentUser, function (success) {
          if (success) {
            notifyPollVote(pollId);
          } else {
            MDS.log("ERROR: Failed to record poll vote");
          }
          callback(); // Continue regardless of vote success
        });
      }
    );
  });
}

function processPaymentTransaction(coin, callback) {
  readPaymentCoin(coin, (paymentState) => {
    const { senderName, description, amount, coinId } = paymentState;
    
    // Create notification directly since strings are already decoded
    notifyPayment(senderName, amount, description, coinId);
    callback();
  });
}

/**
 * Historical Transaction Processing
 * Currently commented out but preserved for future use
 */

/*
function fetchHistoricalTransactions(callback) {
  MDS.net.GET(
    "https://vox-json-storage-production-344d.up.railway.app/transactions",
    (resp) => {
      if (resp.status) {
        try {
          const data = JSON.parse(resp.response);
          if (data && data.transactions && Array.isArray(data.transactions)) {
            // Sort transactions by datetime
            const sortedTransactions = data.transactions.sort((a, b) => {
              return a.datetime - b.datetime;
            });

            MDS.log(`Processing ${sortedTransactions.length} historical transactions`);

            // Process transactions in smaller batches
            const BATCH_SIZE = 25; // Reduced batch size
            let processedCount = 0;

            function processBatch() {
              if (processedCount >= sortedTransactions.length) {
                MDS.log("Finished processing historical transactions");
                callback();
                return;
              }

              // Get the next batch
              const batchEnd = Math.min(processedCount + BATCH_SIZE, sortedTransactions.length);
              const currentBatch = sortedTransactions.slice(processedCount, batchEnd);

              // Process each transaction in the current batch sequentially
              let batchProcessed = 0;
              
              function processNext() {
                if (batchProcessed >= currentBatch.length) {
                  processedCount += currentBatch.length;
                  // Move to next batch immediately
                  processBatch();
                  return;
                }

                const txn = currentBatch[batchProcessed];
                processHistoricalTransaction(txn, () => {
                  batchProcessed++;
                  processNext();
                });
              }

              processNext();
            }

            // Start processing the first batch
            processBatch();
          } else {
            MDS.log("ERROR: No historical transactions found or invalid data format");
            callback();
          }
        } catch (error) {
          MDS.log("ERROR: Parsing historical transactions: " + JSON.stringify(error));
          callback();
        }
      } else {
        MDS.log("ERROR: Fetching historical transactions: " + JSON.stringify(resp.error));
        callback();
      }
    }
  );
}

function processHistoricalTransaction(txn, callback) {
  // Convert API state format to chain transaction format
  const stateObject = {};
  txn.state.forEach((stateItem, index) => {
    stateObject[index] = stateItem.data;
  });

  const coin = {
    coinid: txn.txpow_id,
    state: stateObject,
  };

  // Check transaction type
  const isUpvote = txn.is_upvote === true;
  const isPollVote = stripBrackets(coin.state[8]).toUpperCase() === "POLL";

  if (isUpvote) {
    processTipTransaction(coin, true, callback);
  } else if (isPollVote) {
    processPollVoteTransaction(coin, true, callback);
  } else {
    processPostTransaction(coin, true, callback);
  }
}
*/
