function sqlQuery(query, params, callback) {
  const placeholders = query.match(/\?/g) || [];
  if (placeholders.length !== params.length) {
    throw new Error(
      "Number of parameters doesn't match number of placeholders"
    );
  }

  let index = 0;
  const parameterizedQuery = query.replace(/\?/g, () => {
    const param = params[index++];
    if (typeof param === "string") {
      return "'" + param.replace(/'/g, "''") + "'";
    }
    return param;
  });

  MDS.sql(parameterizedQuery, callback);
}

function wipeDB(callback) {
  // First, disable foreign key constraints
  window.MDS.sql("SET REFERENTIAL_INTEGRITY FALSE", function() {
    console.log("Disabled foreign key checks");
    
    // Get all tables
    window.MDS.sql("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='PUBLIC'", function(result) {
      let tables = result.rows;
      let completedDrops = 0;
      
      console.log("Found tables:", tables);
      
      // Drop each table
      tables.forEach(table => {
        const dropSQL = `DROP TABLE IF EXISTS "${table.TABLE_NAME}" CASCADE`;
        window.MDS.sql(dropSQL, function(msg) {
          console.log(`Attempting to drop table ${table.TABLE_NAME}`);
          if (msg.status) {
            console.log(`Successfully dropped table ${table.TABLE_NAME}`);
          } else {
            console.log(`Error dropping table ${table.TABLE_NAME}:`, msg);
          }
          
          completedDrops++;
          if (completedDrops === tables.length) {
            // Re-enable foreign key constraints
            window.MDS.sql("SET REFERENTIAL_INTEGRITY TRUE", function() {
              console.log("Re-enabled foreign key checks");
              if (callback) {
                callback();
              }
            });
          }
        });
      });
    });
  });
}

function encodeStringForDB(str) {
  if (!str) return "";
  // Check if the string is already JSON
  try {
    JSON.parse(str);
    return str; // It's already JSON, return as is
  } catch (e) {
    // It's not JSON, so stringify it
    return JSON.stringify(str);
  }
}

function decodeStringFromDB(str) {
  if (!str) return "";
  try {
    // First, try to parse it as JSON
    return JSON.parse(str);
  } catch (e) {
    // If parsing fails, it's probably an old-format string
    // Try to decode it as a URI component (old format)
    try {
      return decodeURIComponent(str);
    } catch (e2) {
      // If both methods fail, return the original string
      console.warn("Failed to decode string:", str);
      return str;
    }
  }
}

function createDB(callback) {
  var voxPostsSQL = `CREATE TABLE IF NOT EXISTS vox_posts (
        user_name varchar(128) NOT NULL,
        user_address varchar(128),
        user_pubkey varchar(1024) NOT NULL,
        title varchar(128),
        message varchar(4096) NOT NULL,
        post_id varchar(128) PRIMARY KEY,
        is_read tinyint(1) NOT NULL DEFAULT 0,
        total_tips bigint NOT NULL DEFAULT 0,
        reply_count INT DEFAULT 0,
        created bigint NOT NULL,
        category VARCHAR(10) NOT NULL DEFAULT 'POST'
    )`;

  MDS.sql(voxPostsSQL, function (msg) {
    var tipsSQL = `CREATE TABLE IF NOT EXISTS tips (
            coin_id varchar(128) PRIMARY KEY,
            post_id varchar(128) NOT NULL,
            recipient_address varchar(128) NOT NULL,
            amount decimal(18,9) NOT NULL,
            created bigint NOT NULL,
            is_amp tinyint(1) NOT NULL DEFAULT 0
        )`;

    MDS.sql(tipsSQL, function (msg) {
      const userProfilesSQL = `CREATE TABLE IF NOT EXISTS user_profiles (
        user_pubkey varchar(1024) PRIMARY KEY,
        user_name varchar(128) NOT NULL,
        user_address varchar(128),
        created bigint NOT NULL,
        last_active bigint NOT NULL,
        is_blocked tinyint(1) NOT NULL DEFAULT 0,
        is_subscribed tinyint(1) NOT NULL DEFAULT 0,
        description varchar(500) DEFAULT NULL
  )`;

      MDS.sql(userProfilesSQL, function (msg) {
        const userPrefsSQL = `CREATE TABLE IF NOT EXISTS user_preferences (
                    user_pubkey varchar(1024) PRIMARY KEY,
                    default_tip_amt decimal(10,2) NOT NULL DEFAULT 0.1,
                    confirmation_required tinyint(1) NOT NULL DEFAULT 0
                )`;

        MDS.sql(userPrefsSQL, function (msg) {
          const repliesSQL = `CREATE TABLE IF NOT EXISTS replies (
            user_name VARCHAR(128) NOT NULL,
            user_address VARCHAR(128),
            user_pubkey VARCHAR(1024) NOT NULL,
            reply_id VARCHAR(128) PRIMARY KEY,
            parent_post_id VARCHAR(128) NOT NULL,
            message VARCHAR(4096) NOT NULL,
            created BIGINT NOT NULL,
            total_tips bigint NOT NULL DEFAULT 0,
            FOREIGN KEY (parent_post_id) REFERENCES vox_posts(post_id)
                    )`;

          MDS.sql(repliesSQL, function (msg) {
            if (callback) {
              callback(msg);
            }
          });
        });
      });
    });
  });
}

function getPostByPostId(postId, callback) {
  const sql = `SELECT vp.*, up.user_name 
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE vp.post_id = ?`;

  sqlQuery(sql, [postId], function (sqlResp) {
    if (sqlResp.count > 0) {
      sqlResp.rows[0].user_name = decodeStringFromDB(sqlResp.rows[0].user_name);
      sqlResp.rows[0].message = decodeStringFromDB(sqlResp.rows[0].message);
      // ... decode other fields as necessary
      getRepliesByPostId(postId, function (repliesResp) {
        sqlResp.rows[0].replies = repliesResp.rows;
        callback(sqlResp);
      });
    } else {
      callback(sqlResp);
    }
  });
}

function checkPostExists(postId, callback) {
  getPostByPostId(postId, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function getPostsByUserPubkey(userPubkey, callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE vp.user_pubkey = ?
               ORDER BY vp.created DESC`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    callback(sqlResp);
  });
}

function getAllPosts(callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               ORDER BY vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function getAllPostsBySubscribedUsers(callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE up.is_subscribed = 1
               ORDER BY vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function insertPostUpdateUser(
  postId,
  userName,
  userPubkey,
  userAddress,
  message,
  isRead,
  created,
  description,
  callback
) {
  checkPostExists(postId, function (exists) {
    if (exists) {
      if (callback) {
        callback(false);
      }
      return;
    }

    const enc_user = encodeStringForDB(userName);
    const enc_msg = encodeStringForDB(message);

    const sql = `INSERT INTO vox_posts(user_name, user_address, user_pubkey, message, post_id, is_read, total_tips, created)
                     VALUES (?, ?, ?, ?, ?, ?, 0, ?)`;

    sqlQuery(
      sql,
      [enc_user, userAddress, userPubkey, enc_msg, postId, isRead, created],
      function (sqlResp) {
        checkUserExists(userPubkey, function (exists) {
          if (!exists) {
            addNewUser(
              userPubkey,
              userName,
              userAddress,
              created,
              0,
              0,
              description,
              function (sqlResp) {
                MDS.log("New User added: " + userName);
                callback(true);
              }
            );
          } else {
            updateUserProfile(
              userPubkey,
              userName,
              userAddress,
              created,
              description,
              function (updateResp) {
                callback(true);
              }
            );
          }
        });
      }
    );
  });
}

function getUser(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = ?`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    if (sqlResp.rows && sqlResp.rows.length > 0) {
      const user = sqlResp.rows[0];
      user.DESCRIPTION = user.DESCRIPTION
        ? decodeStringFromDB(user.DESCRIPTION)
        : "";
    }
    callback(sqlResp);
  });
}

function checkUserExists(userPubkey, callback) {
  getUser(userPubkey, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function addNewUser(
  userPubkey,
  userName,
  userAddress,
  created,
  isBlocked,
  isSubscribed,
  description,
  callback
) {
  const enc_user = encodeStringForDB(userName);
  const enc_description = description ? encodeStringForDB(description) : null;

  const sql = `INSERT INTO user_profiles(user_pubkey, user_name, user_address, created, last_active, is_blocked, is_subscribed, description)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

  sqlQuery(
    sql,
    [
      userPubkey,
      enc_user,
      userAddress,
      created,
      created,
      isBlocked,
      isSubscribed,
      enc_description,
    ],
    function (sqlResp) {
      callback(sqlResp);
    }
  );
}

function checkUserBlocked(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = ? AND is_blocked = 1`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function deleteUserMessages(userPubKey, callback) {
  const sql = `DELETE FROM vox_posts WHERE user_pubkey = ?`;

  sqlQuery(sql, [userPubKey], function (sqlResp) {
    callback(true);
  });
}

function blockUser(userPubkey, callback) {
  checkUserBlocked(userPubkey, function (isBlocked) {
    if (isBlocked) {
      MDS.log("User already blocked: " + userPubkey);
      callback(true);
    } else {
      const sql = `UPDATE user_profiles SET is_blocked = 1
                         WHERE user_pubkey = ?`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        deleteUserMessages(userPubkey, function (deleted) {
          if (!deleted) {
            MDS.log("Deletion failed for user: " + userPubkey);
            callback(false);
          }
          callback(true);
        });
      });
    }
  });
}

function unBlockUser(userPubkey, callback) {
  checkUserBlocked(userPubkey, function (isBlocked) {
    if (isBlocked) {
      const sql = `UPDATE user_profiles SET is_blocked = 0
                         WHERE user_pubkey = ?`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        callback(true);
      });
    } else {
      MDS.log("User already unblocked: " + userPubkey);
      callback(true);
    }
  });
}

function getAllBlockedUsers(callback) {
  const sql = "SELECT * FROM user_profiles WHERE is_blocked = 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function checkUserSubscribed(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = ? AND is_subscribed = 1`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function followUser(userPubkey, callback) {
  checkUserSubscribed(userPubkey, function (subscribed) {
    if (subscribed) {
      MDS.log("Already subscribed to: " + userPubkey);
      if (callback) {
        callback(false);
      }
    } else {
      const sql = `UPDATE user_profiles SET is_subscribed = 1
                         WHERE user_pubkey = ?`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        if (callback) {
          callback(sqlResp);
        }
      });
    }
  });
}

function unFollowUser(userPubkey, callback) {
  checkUserSubscribed(userPubkey, function (subscribed) {
    if (!subscribed) {
      MDS.log("Already not subscribed to: " + userPubkey);
      if (callback) {
        callback(false);
      }
    } else {
      const sql = `UPDATE user_profiles SET is_subscribed = 0
                         WHERE user_pubkey = ?`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        if (callback) {
          callback(sqlResp);
        }
      });
    }
  });
}

function getAllSubscribedUsers(callback) {
  const sql = "SELECT * FROM user_profiles WHERE is_subscribed = 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function updatePostScore(postId, tipAmount, isAmp, callback) {
  const sql = `UPDATE vox_posts 
               SET total_tips = total_tips ${isAmp ? "+" : "-"} ?
               WHERE post_id = ?`;

  sqlQuery(sql, [tipAmount, postId], function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function updateReplyScore(replyId, tipAmount, isAmp, callback) {
  const sql = `UPDATE replies 
               SET total_tips = total_tips + ?
               WHERE reply_id = ?`;

  sqlQuery(sql, [isAmp ? tipAmount : -tipAmount, replyId], function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function getTip(coinId, callback) {
  const sql = `SELECT * FROM tips WHERE coin_id = ?`;

  sqlQuery(sql, [coinId], function (sqlResp) {
    callback(sqlResp);
  });
}

function checkIfTipExists(coinId, callback) {
  getTip(coinId, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function addNewTip(coinId, postId, recipientAddress, amount, isAmp, callback) {
  checkIfTipExists(coinId, function (exists) {
    if (!exists) {
      //created
      const startdate = new Date();
      const timemilli = startdate.getTime();

      const sql =
        "INSERT INTO tips(coin_id,post_id,recipient_address,amount,created,is_amp) VALUES( ?,?,?,?,?,?) ";

      sqlQuery(
        sql,
        [coinId, postId, recipientAddress, amount, timemilli, isAmp],
        function (sqlResp) {
          if (callback) {
            callback(true);
          }
        }
      );
    } else {
      callback(false);
    }
  });
}

function getCurrentUserPreferences(callback) {
  const sql = "SELECT * FROM user_preferences LIMIT 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function checkIfUserPrefExists(callback) {
  getCurrentUserPreferences(function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function addUserPreferences(userPubkey, callback) {
  checkIfUserPrefExists(function (exists) {
    if (!exists) {

      const sql = `INSERT INTO user_preferences(user_pubkey) 
                         VALUES(?)`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        if (callback) {
          callback(true);
        }
      });
    } else {
      if (callback) {
        callback(false);
      }
    }
  });
}

function updateUserProfile(
  userPubkey,
  userName,
  userAddress,
  lastActive,
  description,
  callback
) {
  const enc_user = encodeStringForDB(userName);
  const enc_description = description ? encodeStringForDB(description) : null;

  const updateUserSQL = `UPDATE user_profiles 
                         SET user_name = ?,
                             user_address = ?,
                             last_active = ?,
                             description = ?
                         WHERE user_pubkey = ?`;

  sqlQuery(
    updateUserSQL,
    [enc_user, userAddress, lastActive, enc_description, userPubkey],
    function (updateResp) {
      MDS.log("User updated: " + userName);
      if (callback) {
        callback(updateResp);
      }
    }
  );
}

function updateUserPreferences(defaultTipMinima, isConfirmationReq, callback) {
  const sql = `UPDATE user_preferences 
                 SET default_tip_amt = ?, 
                     confirmation_required = ?`;

  sqlQuery(sql, [defaultTipMinima, isConfirmationReq], function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function insertReplyUpdateUser(
  replyId,
  parentPostId,
  userPubkey,
  userName,
  userAddress,
  message,
  created,
  description,
  callback
) {
  const encMessage = encodeStringForDB(message);
  const sql = `INSERT INTO replies (reply_id, parent_post_id, user_pubkey, user_name, user_address, message, created) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`;

  sqlQuery(
    sql,
    [
      replyId,
      parentPostId,
      userPubkey,
      userName,
      userAddress,
      encMessage,
      created,
    ],
    function (sqlResp) {
      updateReplyCount(parentPostId, 1, function () {
        checkUserExists(userPubkey, function (exists) {
          if (!exists) {
            addNewUser(
              userPubkey,
              userName,
              userAddress,
              created,
              0,
              0,
              description,
              function (sqlResp) {
                MDS.log("New User added: " + userName);
                callback(true);
              }
            );
          } else {
            updateUserProfile(
              userPubkey,
              userName,
              userAddress,
              created,
              description,
              function (updateResp) {
                callback(true);
              }
            );
          }
        });
      });
    }
  );
}

function updateReplyCount(postId, increment, callback) {
  const sql = `UPDATE vox_posts 
                 SET reply_count = reply_count + ? 
                 WHERE post_id = ?`;

  sqlQuery(sql, [increment, postId], function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function getRepliesByPostId(postId, callback) {
  const sql = `
    SELECT r.*, up.user_name,
           (SELECT user_address FROM vox_posts WHERE user_pubkey = r.user_pubkey LIMIT 1) as user_address
    FROM replies r
    INNER JOIN user_profiles up ON r.user_pubkey = up.user_pubkey
    WHERE r.parent_post_id = ?
    ORDER BY r.created DESC
  `;

  sqlQuery(sql, [postId], function (sqlResp) {
    callback(sqlResp);
  });
}

function deleteReply(replyId, parentPostId, callback) {
  const sql = `DELETE FROM replies WHERE reply_id = ?`;

  sqlQuery(sql, [replyId], function (sqlResp) {
    updateReplyCount(parentPostId, -1, function () {
      if (callback) {
        callback(sqlResp);
      }
    });
  });
}

function insertArticleUpdateUser(
  postId,
  userName,
  userPubkey,
  userAddress,
  title,
  message,
  isRead,
  created,
  description,
  callback
) {
  checkPostExists(postId, function (exists) {
    if (exists) {
      if (callback) {
        callback(false);
      }
      return;
    }

    const enc_user = encodeStringForDB(userName);
    const enc_msg = encodeStringForDB(message);
    const enc_title = encodeStringForDB(title);

    const sql = `INSERT INTO vox_posts(user_name, user_address, user_pubkey, title, message, post_id, is_read, total_tips, created, category)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, 'ARTICLE')`;

    sqlQuery(
      sql,
      [
        enc_user,
        userAddress,
        userPubkey,
        enc_title,
        enc_msg,
        postId,
        isRead,
        created,
      ],
      function (sqlResp) {
        checkUserExists(userPubkey, function (exists) {
          if (!exists) {
            addNewUser(
              userPubkey,
              userName,
              userAddress,
              created,
              0,
              0,
              description,
              function (sqlResp) {
                MDS.log("New User added: " + userName);
                callback(true);
              }
            );
          } else {
            updateUserProfile(
              userPubkey,
              userName,
              userAddress,
              created,
              description,
              function (updateResp) {
                callback(true);
              }
            );
          }
        });
      }
    );
  });
}
