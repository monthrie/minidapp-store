
function cleanCategory(incategory){
	
	if(!incategory){
		return "";
	}
	
	//Remove spaces
	var newcat = incategory.split(" ").join("");
	
	//Remove double dots
	while(newcat.indexOf("..") != -1){
		newcat = newcat.split("..").join(".");
	}
	
	if(newcat.startsWith(".")){
		newcat = newcat.substring(1);
	}
	
	if(newcat.endsWith(".")){
		newcat = newcat.substring(0,newcat.length-1);
	}
	
	newcat = newcat.replace(/<\/?[^>]+(>|$)/g, "");
	
	return newcat.toLowerCase();
}

function striptags(text){
	return text.replace(/<\/?[^>]+(>|$)/g, "");
}

function isBaseCategory(zCategory,zCheck){
	return zCategory==zCheck || zCategory.startsWith(zCheck+".");
}

function stripBrackets(coinstr){
	
	if(!coinstr){
		return "";
	}
	
	var str = coinstr.trim();
	if(str.startsWith("[")){
		str = str.substring(1);
	}
	
	if(str.endsWith("]")){
		str = str.substring(0,str.length-1);
	}
	
	return str;
}

function cleanMessage(message) {
	let msg = window.DOMPurify.sanitize(message, {
  ALLOWED_TAGS: [
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 
    'p', 'b', 'strong', 'i', 'em', 'u', 's', 
    'blockquote', 'pre', 'code', 'ul', 'ol', 'li', 
    'br', 'hr', 'img', 'video', 'audio', 'a'
  ],
  ALLOWED_ATTR: {
    'a': ['href', 'title'],
    'img': ['src', 'alt', 'title'],
    'video': ['src', 'controls'],
    'audio': ['src', 'controls'],
    '*': ['class', 'id', 'style', 'title']
  }});
	return msg.trim();
}

function isChainMessageValid(post_Id, post_category, post_title, post_msg, post_user, post_randId, post_userPubkey, post_sign) {
	if( post_Id == "" ||
		post_category == "" ||
		post_title == "" ||
		post_msg == "" ||
		post_user == "" ||
		post_randId == "" ||
		post_userPubkey == "" ||
		post_sign == ""
	) {
		return false;
	}
	
	return true;
}


function isChainTipValid(userPubkey, recipientAddress, randId, postId, amount, isAmp, signature) {
	if(	userPubkey == "" ||
		recipientAddress == "" ||
		randId == "" ||
		postId == "" ||
		amount == "" ||
		amount <= 0 ||
		isAmp == "" ||
		signature == ""
	) {
		return false;
	}
	
	return true;
}
