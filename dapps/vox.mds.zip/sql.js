function wipeDB(callback) {
  MDS.sql("DROP TABLE `vox_posts`", function (msg) {
    MDS.sql("DROP TABLE `tips`", function (msg) {
      MDS.sql("DROP TABLE `post_scores`", function (msg) {
        MDS.sql("DROP TABLE `user_profiles`", function (msg) {
          MDS.sql("DROP TABLE `tip_scores`", function (msg) {
            MDS.sql("DROP TABLE `user_preferences`", function (msg) {
              MDS.sql("DROP TABLE `replies`", function (msg) {
                if (callback) {
                  callback();
                }
              });
            });
          });
        });
      });
    });
  });
}

function encodeStringForDB(str) {
  return encodeURIComponent(str).split(" ").join("%20");
}

function decodeStringFromDB(str) {
  return decodeURIComponent(str).split("%20").join(" ");
}

function createDB(callback) {
  var voxPostsSQL = `CREATE TABLE IF NOT EXISTS vox_posts (
        user_name varchar(128) NOT NULL,
        user_address varchar(128),
        user_pubkey varchar(1024) NOT NULL,
        message varchar(4096) NOT NULL,
        post_id varchar(128) PRIMARY KEY,
        is_read tinyint(1) NOT NULL DEFAULT 0,
        total_tips bigint NOT NULL DEFAULT 0,
        reply_count INT DEFAULT 0,
        created bigint NOT NULL
    )`;

  MDS.sql(voxPostsSQL, function (msg) {
    var tipsSQL = `CREATE TABLE IF NOT EXISTS tips (
            coin_id varchar(128) PRIMARY KEY,
            post_id varchar(128) NOT NULL,
            recipient_address varchar(128) NOT NULL,
            amount decimal(18,9) NOT NULL,
            created bigint NOT NULL,
            is_amp tinyint(1) NOT NULL DEFAULT 0
        )`;

    MDS.sql(tipsSQL, function (msg) {
      const userProfilesSQL = `CREATE TABLE IF NOT EXISTS user_profiles (
        user_pubkey varchar(1024) PRIMARY KEY,
        user_name varchar(128) NOT NULL,
        created bigint NOT NULL,
        last_active bigint NOT NULL,
        is_blocked tinyint(1) NOT NULL DEFAULT 0,
        is_subscribed tinyint(1) NOT NULL DEFAULT 0,
        description varchar(500) DEFAULT NULL
  )`;

      MDS.sql(userProfilesSQL, function (msg) {
        const userPrefsSQL = `CREATE TABLE IF NOT EXISTS user_preferences (
                    user_pubkey varchar(1024) PRIMARY KEY,
                    user_name varchar(128) NOT NULL,
                    default_tip_amt bigint NOT NULL DEFAULT 1,
                    confirmation_required tinyint(1) NOT NULL DEFAULT 0
                )`;

        MDS.sql(userPrefsSQL, function (msg) {
          const repliesSQL = `CREATE TABLE IF NOT EXISTS replies (
                        reply_id VARCHAR(128) PRIMARY KEY,
                        parent_post_id VARCHAR(128) NOT NULL,
                        user_pubkey VARCHAR(1024) NOT NULL,
                        message VARCHAR(4096) NOT NULL,
                        created BIGINT NOT NULL,
                        total_tips bigint NOT NULL DEFAULT 0,
                        FOREIGN KEY (parent_post_id) REFERENCES vox_posts(post_id)
                    )`;

          MDS.sql(repliesSQL, function (msg) {
            if (callback) {
              callback(msg);
            }
          });
        });
      });
    });
  });
}

function getPostByPostId(postId, callback) {
  const sql = `SELECT vp.*, up.user_name 
                 FROM vox_posts vp
                 INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
                 WHERE vp.post_id = '${postId}'`;

  MDS.sql(sql, function (sqlResp) {
    if (sqlResp.count > 0) {
      getRepliesByPostId(postId, function (repliesResp) {
        sqlResp.rows[0].replies = repliesResp.rows;
        callback(sqlResp);
      });
    } else {
      callback(sqlResp);
    }
  });
}

function checkPostExists(postId, callback) {
  getPostByPostId(postId, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function getPostsByUserPubkeyOrderByMostRecent(userPubkey, callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE vp.user_pubkey = '${userPubkey}'
               ORDER BY vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function getPostsByUserPubkeyOrderByMostAmp(userPubkey, callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE vp.user_pubkey = '${userPubkey}'
               ORDER BY vp.total_tips DESC, vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function getAllPostsOrderByMostAmp(callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               ORDER BY vp.total_tips DESC, vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function getAllPostsOrderByMostRecent(callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               ORDER BY vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function getAllPostsBySubscribedUsersMostRecent(callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE up.is_subscribed = 1
               ORDER BY vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function getAllPostsBySubscribedUsersMostAmp(callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE up.is_subscribed = 1
               ORDER BY vp.total_tips DESC, vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function insertPostUpdateUser(
  postId,
  userName,
  userPubkey,
  userAddress,
  message,
  isRead,
  created,
  description,
  callback
) {
  checkPostExists(postId, function (exists) {
    if (exists) {
      if (callback) {
        callback(false);
      }
      return;
    }

    const enc_user = encodeStringForDB(userName);
    const enc_msg = encodeStringForDB(message);

    const sql = `INSERT INTO vox_posts(user_name, user_address, user_pubkey, message, post_id, is_read, total_tips, created)
                     VALUES ('${enc_user}', '${userAddress}', '${userPubkey}', '${enc_msg}', '${postId}', ${isRead}, 0, ${created})`;

    MDS.sql(sql, function (sqlResp) {
      checkUserExists(userPubkey, function (exists) {
        if (!exists) {
          addNewUser(
            userPubkey,
            userName,
            created,
            0,
            0,
            description,
            function (sqlResp) {
              MDS.log("New User added: " + userName);
              callback(true);
            }
          );
        } else {
          updateUserProfile(
            userPubkey,
            userName,
            created,
            description,
            function (updateResp) {
              callback(true);
            }
          );
        }
      });
    });
  });
}

function getUser(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = '${userPubkey}'`;

  MDS.sql(sql, function (sqlResp) {
    if (sqlResp.rows && sqlResp.rows.length > 0) {
      const user = sqlResp.rows[0];
      user.DESCRIPTION = user.DESCRIPTION
        ? decodeStringFromDB(user.DESCRIPTION)
        : "";
    }
    callback(sqlResp);
  });
}

function checkUserExists(userPubkey, callback) {
  getUser(userPubkey, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function addNewUser(
  userPubkey,
  userName,
  created,
  isBlocked,
  isSubscribed,
  description,
  callback
) {
  const enc_user = encodeStringForDB(userName);
  const enc_description = description ? encodeStringForDB(description) : null;

  const sql = `INSERT INTO user_profiles(user_pubkey, user_name, created, last_active, is_blocked, is_subscribed, description)
               VALUES ('${userPubkey}', '${enc_user}', '${created}', '${created}', ${isBlocked}, ${isSubscribed}, ${
    enc_description ? `'${enc_description}'` : "NULL"
  })`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function checkUserBlocked(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = '${userPubkey}' AND is_blocked = 1`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function deleteUserMessages(userPubKey, callback) {
  const sql = `DELETE FROM vox_posts WHERE user_pubkey = '${userPubKey}'`;

  MDS.sql(sql, function (sqlResp) {
    callback(true);
  });
}

function blockUser(userPubkey, callback) {
  checkUserBlocked(userPubkey, function (isBlocked) {
    if (isBlocked) {
      MDS.log("User already blocked: " + userPubkey);
      callback(true);
    } else {
      const sql = `UPDATE user_profiles SET is_blocked = 1
                         WHERE user_pubkey = '${userPubkey}'`;

      MDS.sql(sql, function (sqlResp) {
        deleteUserMessages(userPubkey, function (deleted) {
          if (!deleted) {
            MDS.log("Deletion failed for user: " + userPubkey);
            callback(false);
          }
          callback(true);
        });
      });
    }
  });
}

function unBlockUser(userPubkey, callback) {
  checkUserBlocked(userPubkey, function (isBlocked) {
    if (isBlocked) {
      const sql = `UPDATE user_profiles SET is_blocked = 0
                         WHERE user_pubkey = '${userPubkey}'`;

      MDS.sql(sql, function (sqlResp) {
        callback(true);
      });
    } else {
      MDS.log("User already unblocked: " + userPubkey);
      callback(true);
    }
  });
}

function getAllBlockedUsers(callback) {
  const sql = "SELECT * FROM user_profiles WHERE is_blocked = 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function checkUserSubscribed(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = '${userPubkey}' AND is_subscribed = 1`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function subscribeToUser(userPubkey, callback) {
  checkUserSubscribed(userPubkey, function (subscribed) {
    if (subscribed) {
      MDS.log("Already subscribed to: " + userPubkey);
      callback(true);
    } else {
      const sql = `UPDATE user_profiles SET is_subscribed = 1
                         WHERE user_pubkey = '${userPubkey}'`;

      MDS.sql(sql, function (sqlResp) {
        callback(true);
      });
    }
  });
}

function unSubscribeToUser(userPubkey, callback) {
  checkUserSubscribed(userPubkey, function (subscribed) {
    if (!subscribed) {
      MDS.log("Already not subscribed to: " + userPubkey);
      callback(true);
    } else {
      const sql = `UPDATE user_profiles SET is_subscribed = 0
                         WHERE user_pubkey = '${userPubkey}'`;

      MDS.sql(sql, function (sqlResp) {
        callback(true);
      });
    }
  });
}

function getAllSubscribedUsers(callback) {
  const sql = "SELECT * FROM user_profiles WHERE is_subscribed = 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function updatePostScore(postId, tipAmount, isAmp, callback) {
  const sql = `UPDATE vox_posts 
               SET total_tips = total_tips + ${isAmp ? tipAmount : -tipAmount}
               WHERE post_id = '${postId}'`;

  MDS.sql(sql, function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function updateReplyScore(replyId, tipAmount, isAmp, callback) {
  const sql = `UPDATE replies 
               SET total_tips = total_tips + ${isAmp ? tipAmount : -tipAmount}
               WHERE reply_id = '${replyId}'`;

  MDS.sql(sql, function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function getTip(coinId, callback) {
  const sql = `SELECT * FROM tips WHERE coin_id = '${coinId}'`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function checkIfTipExists(coinId, callback) {
  getTip(coinId, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function addNewTip(coinId, postId, recipientAddress, amount, isAmp, callback) {
  checkIfTipExists(coinId, function (exists) {
    if (!exists) {
      //created
      const startdate = new Date();
      const timemilli = startdate.getTime();

      const sql =
        "INSERT INTO tips(coin_id,post_id,recipient_address,amount,created,is_amp) VALUES( '" +
        coinId +
        "','" +
        postId +
        "','" +
        recipientAddress +
        "'," +
        amount +
        "," +
        timemilli +
        "," +
        isAmp +
        ") ";

      MDS.sql(sql, function (sqlResp) {
        if (callback) {
          callback(true);
        }
      });
    } else {
      callback(false);
    }
  });
}

function getCurrentUserPreferences(callback) {
  const sql = "SELECT * FROM user_preferences LIMIT 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function checkIfUserPrefExists(callback) {
  getCurrentUserPreferences(function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function addUserPreferences(userPubkey, userName, callback) {
  checkIfUserPrefExists(function (exists) {
    if (!exists) {
      const encUser = encodeStringForDB(userName);

      const sql = `INSERT INTO user_preferences(user_pubkey, user_name) 
                         VALUES('${userPubkey}', '${encUser}')`;

      MDS.sql(sql, function (sqlResp) {
        if (callback) {
          callback(true);
        }
      });
    } else {
      if (callback) {
        callback(false);
      }
    }
  });
}

function updateUserProfile(
  userPubkey,
  userName,
  created,
  description,
  callback
) {
  const enc_user = encodeStringForDB(userName);
  const enc_description = description ? encodeStringForDB(description) : null;

  const updateUserSQL = `UPDATE user_profiles 
                         SET user_name = '${enc_user}',
                             last_active = ${created},
                             description = ${
                               enc_description ? `'${enc_description}'` : "NULL"
                             }
                         WHERE user_pubkey = '${userPubkey}'`;

  MDS.sql(updateUserSQL, function (updateResp) {
    MDS.log("User updated: " + userName);
    if (callback) {
      callback(updateResp);
    }
  });
}

function updateUserPreferences(defaultTipAmnt, isConfirmationReq, callback) {
  const sql = `UPDATE user_preferences 
                 SET default_tip_amt = ${defaultTipAmnt}, 
                     confirmation_required = ${isConfirmationReq}`;

  MDS.sql(sql, function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function addReply(
  replyId,
  parentPostId,
  userPubkey,
  userName,
  message,
  created,
  description,
  callback
) {
  const encMessage = encodeStringForDB(message);
  const sql = `INSERT INTO replies (reply_id, parent_post_id, user_pubkey, message, created) 
                 VALUES ('${replyId}', '${parentPostId}', '${userPubkey}', '${encMessage}', ${created})`;

  MDS.sql(sql, function (sqlResp) {
    updateReplyCount(parentPostId, 1, function () {
      checkUserExists(userPubkey, function (exists) {
        if (!exists) {
          addNewUser(
            userPubkey,
            userName,
            created,
            0,
            0,
            description,
            function (sqlResp) {
              MDS.log("New User added: " + userName);
              callback(true);
            }
          );
        } else {
          updateUserProfile(
            userPubkey,
            userName,
            created,
            description,
            function (updateResp) {
              callback(true);
            }
          );
        }
      });
    });
  });
}

function updateReplyCount(postId, increment, callback) {
  const sql = `UPDATE vox_posts 
                 SET reply_count = reply_count + ${increment} 
                 WHERE post_id = '${postId}'`;

  MDS.sql(sql, function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function getRepliesByPostId(postId, callback) {
  const sql = `
    SELECT r.*, up.user_name,
           (SELECT user_address FROM vox_posts WHERE user_pubkey = r.user_pubkey LIMIT 1) as user_address
    FROM replies r
    INNER JOIN user_profiles up ON r.user_pubkey = up.user_pubkey
    WHERE r.parent_post_id = '${postId}'
    ORDER BY r.created DESC
  `;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function deleteReply(replyId, parentPostId, callback) {
  const sql = `DELETE FROM replies WHERE reply_id = '${replyId}'`;

  MDS.sql(sql, function (sqlResp) {
    updateReplyCount(parentPostId, -1, function () {
      if (callback) {
        callback(sqlResp);
      }
    });
  });
}

function updateUserDescription(userPubkey, description, callback) {
  // Özel encodeStringForDB fonksiyonunu kullan
  const encodedDescription = encodeStringForDB(description);

  const sql = `MERGE INTO user_profiles KEY (user_pubkey)
               VALUES ('${userPubkey}', 
                       COALESCE((SELECT user_name FROM user_profiles WHERE user_pubkey = '${userPubkey}'), ''),
                       COALESCE((SELECT created FROM user_profiles WHERE user_pubkey = '${userPubkey}'), ${Date.now()}),
                       ${Date.now()},
                       COALESCE((SELECT is_blocked FROM user_profiles WHERE user_pubkey = '${userPubkey}'), 0),
                       COALESCE((SELECT is_subscribed FROM user_profiles WHERE user_pubkey = '${userPubkey}'), 0),
                       '${encodedDescription}')`;

  MDS.sql(sql, function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

