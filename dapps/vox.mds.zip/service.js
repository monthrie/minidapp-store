/**
 * SHOUTOUT backend service
 *
 * @spartacusrex
 */

//Load js libs
MDS.load("puresha1.js");
MDS.load("jslib.js");
MDS.load("sql.js");
MDS.load("txn.js");

//Are we logging data
var logs = true;

var USER_NAME = "";
var USER_PUBKEY = "";
var USER_ADDRESS = "Mx999";
const SHOUTOUT_ADDRESS = "0x6D696E69766F782061646472657373";
const MINIVOX_ADDRESS =
  "0x789DE9ADB2241184E7EBB4B5D59C46AE36A768C5E573AF2ECFBA8C877F9EA2D6";

function checkTxn(msg) {
  if (msg.data.coin.tokenid != "0x00") {
    MDS.log("Message not sent as Minima.. ! " + msg.data.coin.tokenid);
    return false;
  } else if (+msg.data.coin.amount < 0.01) {
    MDS.log("Message below 0.01 threshold.. ! " + msg.data.coin.amount);
    return false;
  }
  return true;
}

//Main message handler
MDS.init(function (msg) {
  if (msg.event == "inited") {
    if (false) {
      wipeDB();
      MDS.log("DB Wiped");
    } else {
      createDB(() => {
        MDS.cmd(
          "coinnotify action:add address:" + SHOUTOUT_ADDRESS,
          function (startup) {}
        );
        MDS.cmd(
          "coinnotify action:add address:" + MINIVOX_ADDRESS,
          function (startup) {}
        );
        MDS.log("DataBase up and running.");
      });

      MDS.cmd("maxima;getaddress", function (startup) {
        //Get the user details
        USER_NAME = startup[0].response.name;
        USER_PUBKEY = startup[0].response.publickey;

        //Add these details into user_preferences table
        addUserPreferences(USER_PUBKEY, USER_NAME, function (inserted) {
          if (inserted) {
            MDS.log("User Preferences added to table.");
          }
        });

        //Now see if we have picked an address..
        var someaddress = startup[1].response.address;
        MDS.keypair.get("shoutaddress", function (resp) {
          if (resp.status) {
            //We have already defined it..
            USER_ADDRESS = resp.value;
            MDS.log("Address found.. " + USER_ADDRESS);
          } else {
            USER_ADDRESS = someaddress;
            //None specified yet - specify it..
            MDS.keypair.set("shoutaddress", someaddress, function (resp) {
              MDS.log("NEW address set.. " + someaddress);
            });
          }
        });
      });
    }
  } else if (msg.event == "NOTIFYCOIN") {
    //Check if it's a message
    if (msg.data.address == SHOUTOUT_ADDRESS) {
      MDS.log("received on shoutout address");
      //Check if valid amount
      if (!checkTxn(msg)) {
        MDS.log("ERROR: Invalid Message");
        return;
      }

      //Insert into DB
      //Check if state is valid
      const post_category = stripBrackets(msg.data.coin.state[0]);
      const post_title = stripBrackets(msg.data.coin.state[1]);
      const post_msg = stripBrackets(msg.data.coin.state[2]);
      const post_userName = stripBrackets(msg.data.coin.state[3]);
      const post_randId = stripBrackets(msg.data.coin.state[4]);
      const post_userPubkey = stripBrackets(msg.data.coin.state[5]);
      const post_sign = stripBrackets(msg.data.coin.state[6]);
      const post_address = stripBrackets(msg.data.coin.state[7]);
      const post_created = stripBrackets(msg.data.coin.state[8]);
      const post_description = stripBrackets(msg.data.coin.state[9]);
      const post_Id = msg.data.coin.coinid;

      if (!post_Id) {
        MDS.log("ERROR: undefined coinId.");
        return;
      }

      if (
        !isChainMessageValid(
          post_Id,
          post_category,
          post_title,
          post_msg,
          post_userName,
          post_randId,
          post_userPubkey,
          post_sign,
          post_description
        )
      ) {
        MDS.log("Cannot have blank details in message.");
        return;
      }

      checkUserBlocked(post_userPubkey, function (isBlocked) {
        if (!isBlocked) {
          checkMessageSig(
            post_category,
            post_title,
            post_msg,
            post_userName,
            post_userPubkey,
            post_address,
            post_randId,
            post_created,
            post_description,
            post_sign,
            function (valid) {
              if (!valid) {
                MDS.log("Invalid Message Signature for: " + post_userName);
                return;
              }

              const isRead = post_userPubkey == USER_PUBKEY ? 1 : 0;

              if (post_category === "REPLY") {
                // This is a reply
                addReply(
                  post_Id,
                  post_title,
                  post_userPubkey,
                  post_userName,
                  post_msg,
                  post_created,
                  post_description,
                  function (inserted) {
                    if (inserted) {
                      MDS.log("Reply inserted successfully.");
                      updateReplyCount(post_title, 1, function () {
                        MDS.log("Reply count updated for post: " + post_title);
                      });
                      // Notify about the new reply
                      notifyReply(post_title, post_userName, post_msg);
                    }
                  }
                );
              } else {
                // This is a regular post
                insertPostUpdateUser(
                  post_Id,
                  post_userName,
                  post_userPubkey,
                  post_address,
                  post_msg,
                  isRead,
                  post_created,
                  post_description,
                  function (inserted) {
                    if (inserted) {
                      MDS.log("Post inserted and user details updated.");
                      checkUserSubscribed(
                        post_userPubkey,
                        function (subscribed) {
                          if (subscribed) {
                            //push a notification if the user is subscribed to
                            var notificationMsg =
                              post_userName + ": " + post_msg;
                            if (notificationMsg.length > 40) {
                              notificationMsg =
                                notificationMsg.substring(0, 40) + "...";
                            }
                            MDS.log("Notification fired.");
                            MDS.notify(notificationMsg);
                          }
                        }
                      );
                    }
                  }
                );
              }
            }
          );
        }
      });
    } else if (msg.data.address === MINIVOX_ADDRESS) {
      //Check if valid amount
      MDS.log("received on minivox address");
      if (!checkTxn(msg)) {
        MDS.log("ERROR: Invalid Message");
        return;
      }

      //Insert into DB
      const userPubkey = stripBrackets(msg.data.coin.state[0]);
      const recipientAddress = stripBrackets(msg.data.coin.state[1]);
      const randId = stripBrackets(msg.data.coin.state[2]);
      const postId = stripBrackets(msg.data.coin.state[3]);
      const amount = stripBrackets(msg.data.coin.state[4]);
      const signature = stripBrackets(msg.data.coin.state[5]);
      const isAmp = stripBrackets(msg.data.coin.state[6]);

      if (
        !isChainTipValid(
          userPubkey,
          recipientAddress,
          randId,
          postId,
          amount,
          isAmp,
          signature
        )
      ) {
        MDS.log("ERROR: Cannot have blank details in tip.");
        return;
      }
      MDS.log("Valid Tip Message");

      const coinId = msg.data.coin.coinid;

      if (!coinId) {
        MDS.log("ERROR: undefined coinId.");
        return;
      }
      MDS.log("Valid CoinId");

      checkTipSig(
        userPubkey,
        recipientAddress,
        randId,
        postId,
        amount,
        isAmp,
        signature,
        function (valid) {
          if (!valid) {
            MDS.log("Invalid Tip Signature for: " + userPubkey);
            return;
          }
          MDS.log("Valid Tip Signature");

          //valid
          addNewTip(
            coinId,
            postId,
            recipientAddress,
            amount,
            isAmp,
            function (resp) {
              if (resp) {
                MDS.log("Tip Added: " + coinId);
                //update post score if post exists
                updatePostScore(postId, amount, isAmp, function (sqlResp) {
                  MDS.log("Post score updated: " + postId);
                });
              }
              else (
                MDS.log("ERROR: Tip not added." + resp)
              )
            }
          );
        }
      );
    }
  }
});

function notifyReply(parentPostId, replyUserName, replyMsg) {
  getPostByPostId(parentPostId, function (post) {
    if (post.count > 0) {
      const originalPost = post.rows[0];
      let notificationMsg = `${replyUserName} replied to your post: ${replyMsg}`;
      if (notificationMsg.length > 40) {
        notificationMsg = notificationMsg.substring(0, 40) + "...";
      }
      MDS.log("Reply Notification fired.");
      MDS.notify(notificationMsg, originalPost.USER_PUBKEY);
    }
  });
}
