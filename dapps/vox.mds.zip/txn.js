function getMessageHash(category, title, message, user, pubkey, address, randId, created, description){
  //Create one long string..
  var fullmessage = category+title+message+user+pubkey+address+randId+created+description+"";
  var urlencoded  = encodeURIComponent(fullmessage);
  
  //Now hash it..
  return sha1(urlencoded);
}

function checkMessageSig(category, title, message, user, pubkey, address, randId, created, description, signature, callback){
  
  //First create the message signature..
  var hash = getMessageHash(category, title, message, user, pubkey, address, randId, created, description);
  
  //Now sign the hash..
  MDS.cmd("maxverify data:"+hash+" publickey:"+pubkey+" signature:"+signature,function(ver){
    if(ver.response.valid){
      callback(true);
    }else{
      callback(false);
    }   
  });
}

function sendTxnMessage(category, title, message, user, pubkey, address, randId, created, description, callback){
  
  //First create the message signature..
  var hash = getMessageHash(category, title, message, user, pubkey, address, randId, created, description);
    
  //Now sign the hash..
  MDS.cmd("maxsign data:"+hash,function(resp){
    var signature = resp.response.signature;
  
    //Now construct..
    var state = {};
    state[0] = "["+category+"]";
    state[1] = "["+title+"]";
    state[2] = "["+message+"]";
    state[3] = "["+user+"]";
    state[4] = randId+"";
    state[5] = pubkey+"";
    state[6] = signature+"";
    state[7] = "["+address+"]";
    state[8] = created+"";
    state[9] = "["+description+"]";
    
    var func = "send storestate:false amount:0.01 address:"+window.SHOUTOUT_ADDRESS+" state:"+JSON.stringify(state);
    
    //run it..
    MDS.cmd(func,function(sendresp){
      if(callback){
        callback(sendresp);
      }
    });   
  });
}

// TIPS

function getTipHash(userPubkey, recipientAddr, randId, postId, amount, isAmp) {
  const tipdata = userPubkey + recipientAddr + randId + postId + amount + isAmp +"";
  const urlencoded = encodeURIComponent(tipdata);

  return sha1(urlencoded);
}

function checkTipSig(userPubkey, recipientAddr, randId, postId, amount, isAmp, signature, callback){
  
  //First create the tip signature..
  var hash = getTipHash(userPubkey, recipientAddr, randId, postId, amount, isAmp);
  
  //Now verify the signature..
  MDS.cmd("maxverify data:"+hash+" publickey:"+userPubkey+" signature:"+signature, function(ver) { 
    if(ver.response.valid){
      callback(true);
    }else{
      callback(false);
    }   
  });
}

function sendTxnTip(userPubkey, recipientAddr, randId, postId, amount, isAmp, callback){
  //First create the tip signature..
  var hash = getTipHash(
    userPubkey,
    recipientAddr,
    randId,
    postId,
    amount,
    isAmp
  );

  //Now sign the hash..
  MDS.cmd("maxsign data:" + hash, function (resp) {
    var signature = resp.response.signature;

    //Now construct..
    var state = {};
    state[0] = userPubkey + "";
    state[1] = "[" + recipientAddr + "]";
    state[2] = randId + "";
    state[3] = "[" + postId + "]";
    state[4] = amount + "";
    state[5] = signature + "";
    state[6] = isAmp + "";

    const tip = isAmp
      ? Math.round((amount / 2 + Number.EPSILON) * 100) / 100
      : amount;
    //const tip = isAmp ? Math.round(amount/2) : 1;

    const func = isAmp
      ? `send multi:["${recipientAddr}:${tip}","${window.MINIVOX_ADDRESS}:${
          amount != tip ? amount - tip : tip
        }"] state:${JSON.stringify(state)}`
      : `send storestate:false amount:${tip} address:${
          window.MINIVOX_ADDRESS
        } state:${JSON.stringify(state)}`;

    //run it..
    MDS.cmd(func, function (sendresp) {
      if (callback) {
        callback(sendresp);
      }
    });
  });
}