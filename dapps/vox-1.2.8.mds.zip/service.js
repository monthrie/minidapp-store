/**
 * MINIVOX backend service
 *
 * @spartacusrex
 */

//Load js libs
MDS.load("puresha1.js");
MDS.load("jslib.js");
MDS.load("sql.js");
MDS.load("txn.js");

//Are we logging data
var logs = true;

var USER_NAME = "";
var USER_PUBKEY = "";
var USER_ADDRESS = "Mx999";
const MINIVOX_ADDRESS = "0x6D696E69766F782061646472657373";
const MINIVOX_TIP_ADDRESS = "0x4D494E49564F585F414444524553";

function checkTxn(msg) {
  if (msg.data.coin.tokenid != "0x00") {
    MDS.log("Message not sent as Minima.. ! " + msg.data.coin.tokenid);
    return false;
  } else if (+msg.data.coin.amount < 0.01) {
    MDS.log("Message below 0.01 threshold.. ! " + msg.data.coin.amount);
    return false;
  }
  return true;
}

//Main message handler
MDS.init(function (msg) {
  if (msg.event == "inited") {
    if (false) {
      wipeDB();
      MDS.log("DB Wiped");
    } else {
      createDB(() => {
        MDS.cmd(
          "coinnotify action:add address:" + MINIVOX_ADDRESS,
          function (startup) {}
        );
        MDS.cmd(
          "coinnotify action:add address:" + MINIVOX_TIP_ADDRESS,
          function (startup) {}
        );
        MDS.log("DataBase up and running.");
      });

      MDS.cmd("maxima;getaddress", function (startup) {
        //Get the user pubkey
        USER_PUBKEY = startup[0].response.publickey;

        // Get user from profiles table
        getUser(USER_PUBKEY, function (userResp) {
          if (userResp.count > 0) {
            // User exists in profiles, use that name
            USER_NAME = decodeStringFromDB(userResp.rows[0].USER_NAME);
          } else {
            // User doesn't exist, use Maxima name and create new user
            USER_NAME = startup[0].response.name;
            addNewUser(
              USER_PUBKEY,
              USER_NAME,
              USER_ADDRESS,
              Date.now(),
              0,
              0,
              null,
              function (sqlResp) {
                MDS.log("New User added: " + USER_NAME);
              }
            );
          }

          // Add/update user preferences
          addUserPreferences(USER_PUBKEY, function (inserted) {
            if (inserted) {
              MDS.log("User Preferences added to table.");
            }
          });
        });

        //Now see if we have picked an address..
        var someaddress = startup[1].response.address;
        MDS.keypair.get("shoutaddress", function (resp) {
          if (resp.status) {
            //We have already defined it..
            USER_ADDRESS = resp.value;
            MDS.log("Address found.. " + USER_ADDRESS);
          } else {
            USER_ADDRESS = someaddress;
            //None specified yet - specify it..
            MDS.keypair.set("shoutaddress", someaddress, function (resp) {
              MDS.log("NEW address set.. " + someaddress);
            });
          }
        });
      });
    }
  } else if (msg.event == "NOTIFYCOIN") {
    MDS.log("NOTIFYCOIN received - Address: " + msg.data.address);
    MDS.log("Message data: " + JSON.stringify(msg.data));
    
    //Check if it's a message
    if (msg.data.address == MINIVOX_ADDRESS) {
      MDS.log("Processing MINIVOX message");
      //Check if valid amount
      if (!checkTxn(msg)) {
        MDS.log("ERROR: Invalid Message - Failed transaction check");
        return;
      }
      MDS.log("Transaction check passed");

      //Insert into DB
      //Check if state is valid
      const post_category = stripBrackets(msg.data.coin.state[0]);
      MDS.log("Post category: " + post_category);
      const post_title = stripBrackets(msg.data.coin.state[1]);
      const post_msg = stripBrackets(msg.data.coin.state[2]);
      const post_userName = stripBrackets(msg.data.coin.state[3]);
      const post_randId = stripBrackets(msg.data.coin.state[4]);
      const post_userPubkey = stripBrackets(msg.data.coin.state[5]);
      const post_sign = stripBrackets(msg.data.coin.state[6]);
      const post_address = stripBrackets(msg.data.coin.state[7]);
      const post_created = stripBrackets(msg.data.coin.state[8]);
      const post_description = stripBrackets(msg.data.coin.state[9]);
      const post_Id = msg.data.coin.coinid;

      if (!post_Id) {
        MDS.log("ERROR: undefined coinId. Raw data: " + JSON.stringify(msg.data.coin));
        return;
      }

      MDS.log("Validating chain message...");
      if (!isChainMessageValid(
        post_Id,
        post_category,
        post_title,
        post_msg,
        post_userName,
        post_randId,
        post_userPubkey,
        post_sign,
        post_description
      )) {
        MDS.log("ERROR: Chain message validation failed - Details:");
        MDS.log(`ID: ${post_Id}, Category: ${post_category}, Title: ${post_title}`);
        MDS.log(`Message: ${post_msg}, User: ${post_userName}`);
        return;
      }
      MDS.log("Chain message validation passed");

      checkUserBlocked(post_userPubkey, function (isBlocked) {
        if (!isBlocked) {
          MDS.log("Checking message signature...");
          checkMessageSig(
            post_category,
            post_title,
            post_msg,
            post_userName,
            post_userPubkey,
            post_address,
            post_randId,
            post_created,
            post_description,
            post_sign,
            function (valid) {
              if (!valid) {
                MDS.log("Invalid Message Signature for: " + post_userName);
                return;
              }
              MDS.log("Message signature validation passed");
              const isRead = post_userPubkey == USER_PUBKEY ? 1 : 0;

              // Handle different post categories
              switch (post_category) {
                case "ARTICLE":
                  insertArticleUpdateUser(
                    post_Id,
                    post_userName,
                    post_userPubkey,
                    post_address,
                    post_title,
                    post_msg,
                    isRead,
                    post_created,
                    post_description,
                    function (inserted) {
                      if (inserted) {
                        MDS.log("Article inserted successfully.");
                        notifyPost(post_userName, post_msg);
                      }
                    }
                  );
                  break;

                case "REPLY":
                  insertReplyUpdateUser(
                    post_Id,
                    post_title,
                    post_userPubkey,
                    post_userName,
                    post_address,
                    post_msg,
                    post_created,
                    post_description,
                    function (inserted) {
                      if (inserted) {
                        MDS.log("Reply inserted successfully.");
                        updateReplyCount(post_title, 1, function () {
                          MDS.log("Reply count updated for post: " + post_title);
                        });
                        notifyReply(post_title, post_userName, post_msg);
                      }
                    }
                  );
                  break;

                case "POST":
                default:
                  insertPostUpdateUser(
                    post_Id,
                    post_userName,
                    post_userPubkey,
                    post_address,
                    post_msg,
                    isRead,
                    post_created,
                    post_description,
                    function (inserted) {
                      if (inserted) {
                        MDS.log("Post inserted successfully.");
                        notifyPost(post_userName, post_msg);
                      }
                    }
                  );
                  break;
              }
            }
          );
        }
      });
    } else if (msg.data.address === MINIVOX_TIP_ADDRESS) {
      MDS.log("Processing MINIVOX tip");
      MDS.log("Message data: " + JSON.stringify(msg.data));
      
      if (!checkTxn(msg)) {
        MDS.log("ERROR: Invalid Message - Failed transaction check");
        return;
      }
      MDS.log("Transaction check passed");

      //Insert into DB
      const userPubkey = stripBrackets(msg.data.coin.state[0]);
      const recipientAddress = stripBrackets(msg.data.coin.state[1]);
      const recipientPubkey = stripBrackets(msg.data.coin.state[2]);
      const randId = stripBrackets(msg.data.coin.state[3]);
      const postId = stripBrackets(msg.data.coin.state[4]);
      const amount = stripBrackets(msg.data.coin.state[5]);
      const signature = stripBrackets(msg.data.coin.state[6]);
      const isAmp = stripBrackets(msg.data.coin.state[7]);
      const isReply = msg.data.coin.state[8].toUpperCase() === "TRUE";

      MDS.log(msg.data.coin.state[7]);
      if (
        !isChainTipValid(
          userPubkey,
          recipientAddress,
          randId,
          postId,
          amount,
          isAmp,
          signature
        )
      ) {
        MDS.log("ERROR: Cannot have blank details in tip.");
        return;
      }
      MDS.log("Valid Tip Message");

      const coinId = msg.data.coin.coinid;

      if (!coinId) {
        MDS.log("ERROR: undefined coinId.");
        return;
      }
      MDS.log("Valid CoinId");

      checkTipSig(
        userPubkey,
        recipientAddress,
        recipientPubkey,
        randId,
        postId,
        amount,
        isAmp,
        isReply,
        signature,
        function (valid) {
          if (!valid) {
            MDS.log("Invalid Tip Signature for: " + userPubkey);
            return;
          }
          MDS.log("Valid Tip Signature");

          const voteScore = amount * 10;
          const isAmpBool = isAmp === "1";

          //valid
          addNewTip(
            coinId,
            postId,
            recipientAddress,
            voteScore,
            isAmpBool,
            function (resp) {
              if (resp) {
                MDS.log("Tip Added: " + coinId);
                
                // Move notification after score update
                const updateScoreFunction = isReply ? updateReplyScore : updatePostScore;
                updateScoreFunction(postId, voteScore, isAmp, function (sqlResp) {
                  MDS.log("Post score updated: " + postId);
                  updateUserScore(recipientPubkey, parseInt(voteScore), function (scoreResp) {
                    MDS.log("User score updated: " + scoreResp);
                    
                    // First notify the tip
                    notifyTip(postId, voteScore);
                    
                    // Then send the NEWTIP event after all updates are complete
                    MDS.comms.solo(
                      JSON.stringify({
                        target: "client",
                        event: "NEWTIP",
                        recipientPubkey: recipientPubkey,
                      }),
                      function (resp) {
                        MDS.log("New tip notification sent: " + JSON.stringify(resp));
                      }
                    );
                  });
                });
              } else MDS.log("ERROR: Tip not added. " + resp);
            }
          );
        }
      );
    } else {
      MDS.log("Message received for unknown address: " + msg.data.address);
    }
  }
});

function notifyPost(postUserName, postMsg) {
  let notificationMsg = `${postUserName} posted: ${postMsg}`;
  if (notificationMsg.length > 40) {
    notificationMsg = notificationMsg.substring(0, 40) + "...";
  }
  MDS.comms.solo(
    JSON.stringify({ target: "client", event: "NEWPOST" }),
    function (resp) {
      MDS.notify(notificationMsg);
      MDS.log("New post notification sent: " + resp);
    }
  );
}

function notifyReply(parentPostId, replyUserName, replyMsg) {
  getPostByPostId(parentPostId, function (post) {
    if (post.count > 0) {
      const originalPost = post.rows[0];
      if (originalPost.USER_PUBKEY === USER_PUBKEY) {
        let notificationMsg = `${replyUserName} replied to your post: ${replyMsg}`;
        if (notificationMsg.length > 40) {
          notificationMsg = notificationMsg.substring(0, 40) + "...";
        }
        MDS.notify(notificationMsg);
      }
    }
  });
}

function notifyTip(recipientPubkey, tipAmount) {
  if (recipientPubkey === USER_PUBKEY) {
    let notificationMsg = `Your post received ${tipAmount > 1 ? 'upvotes' : 'an upvote'}`;
    MDS.notify(notificationMsg);
  }
}
